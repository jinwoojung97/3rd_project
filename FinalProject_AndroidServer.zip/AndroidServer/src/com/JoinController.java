package com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/JoinController")
public class JoinController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("ȸ������ ��û�� ����..!");
		
		String member_id = request.getParameter("join_id");
		String member_pw = request.getParameter("join_pw");
		String member_phone = request.getParameter("join_phone");
		String member_region = request.getParameter("join_region");
		
		System.out.println(member_id+"/"+member_pw+"/"+member_phone+"/"+member_region);
		
		MemberDAO dao = new MemberDAO();
		
		int cnt = dao.join(new MemberVO(member_id, member_pw, member_phone, member_region));
		
		dao.join_point(new MemberVO(member_id));
		
		PrintWriter out = response.getWriter();
		
		if(cnt > 0) { //���Լ�����
			
			out.print("1");
		}else { //���Խ��н�
			out.print("0");
		}
		
		
	}

}
