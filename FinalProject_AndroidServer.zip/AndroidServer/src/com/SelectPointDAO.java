//package com;
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//
//public class SelectPointDAO {
//	private Connection conn;
//	private PreparedStatement pst;
//	private ResultSet rs;
//	private int cnt,cnt1;
//	
//	public void conn() {
//		try {
//			Class.forName("oracle.jdbc.driver.OracleDriver");
//			String db_url = "jdbc:oracle:thin:@localhost:1521:xe";
//			String db_id = "hr";
//			String db_pw = "hr";
//
//			conn = DriverManager.getConnection(db_url, db_id, db_pw);
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//		}	
//	}
//	
//	public void close() {
//		try {
//			if(rs != null) {
//				rs.close();
//			}	
//			if (pst != null) {
//				pst.close();
//			}
//			if(conn != null) {
//				conn.close();
//			}
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//	}
//	
//	public MemberVO selectMemberPoint(String member_id) {
//		conn();
//		
//		int vo = 0;
//		
//		try {
//			String sql = "select member_point from member where member_id = ?";
//			pst = conn.prepareStatement(sql);
//			pst.setString(1, member_id);
//			rs = pst.executeQuery();
//			
//			if(rs.next()) {
//				int get_member_point = rs.getInt(1);
//				
//				
//				
//				vo = new MemberVO(get_member_point);
//			}
//			
//		} catch (SQLException e) {
//			e.printStackTrace();
//			System.out.println("�α��� ����");
//		} finally {
//			close();
//		}
//		
//		return vo;
//	
//	}
//
//}
