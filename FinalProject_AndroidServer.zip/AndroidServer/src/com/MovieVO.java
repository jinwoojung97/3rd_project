package com;

public class MovieVO {
    
    private String rank;
    private String rankOldAndNew;
    private String movieNm;
    private String audiAcc;
    private String openDt;

    public MovieVO(String rank, String rankOldAndNew, String movieNm, String audiAcc, String openDt) {
        this.rank = rank;
        this.rankOldAndNew = rankOldAndNew;
        this.movieNm = movieNm;
        this.audiAcc = audiAcc;
        this.openDt = openDt;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getRankOldAndNew() {
        return rankOldAndNew;
    }

    public void setRankOldAndNew(String rankOldAndNew) {
        this.rankOldAndNew = rankOldAndNew;
    }

    public String getMovieNm() {
        return movieNm;
    }

    public void setMovieNm(String movieNm) {
        this.movieNm = movieNm;
    }

    public String getAudiAcc() {
        return audiAcc;
    }

    public void setAudiAcc(String audiAcc) {
        this.audiAcc = audiAcc;
    }

    public String getOpenDt() {
        return openDt;
    }

    public void setOpenDt(String openDt) {
        this.openDt = openDt;
    }
}
