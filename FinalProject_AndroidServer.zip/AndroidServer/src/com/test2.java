package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;


@WebServlet("/test2")
public class test2 extends HttpServlet {

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//ArrayList��ü ���� >> JSON��ü�� ��ȯ
		ArrayList<MovieVO> data = new ArrayList<MovieVO>();
		
		data.add(new MovieVO("1,","OLD","����","123540","2021-04-15"));
		data.add(new MovieVO("2,","OLD","��Ž���ڳ�","53115","2021-04-16"));
		data.add(new MovieVO("3,","OLD","��Į","56351","2021-01-27"));
		data.add(new MovieVO("4,","OLD","�ڻ�","54353","2021-03-31"));
		data.add(new MovieVO("5,","OLD","��ٵ�","8641","2021-04-07"));
		data.add(new MovieVO("6,","OLD","�̳���","131354","2021-03-03"));
		data.add(new MovieVO("7,","OLD","����������","64313","2021-04-15"));
		data.add(new MovieVO("8,","OLD","��ŵ巣��","8744","2021-04-15"));
		data.add(new MovieVO("9,","OLD","��������","64741","2021-03-25"));
		data.add(new MovieVO("10,","OLD","��ʹ��","31354","2021-04-28"));
		
		//GSON��ü ����
		Gson gson = new Gson();
		
		String jsonArr=gson.toJson(data);
		
		System.out.println(jsonArr);
		
		//APP���� JSON������ ������
		response.setContentType("text/plain; charset=utf-8");
		PrintWriter out = response.getWriter();
		
		out.print(jsonArr);
		
	}

}
