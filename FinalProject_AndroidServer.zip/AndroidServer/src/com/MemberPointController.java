//package com;
//
//import java.io.IOException;
//import java.io.PrintWriter;
//
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//
//@WebServlet("/MemberPointController")
//public class MemberPointController extends HttpServlet {
//	private static final long serialVersionUID = 1L;
//
//	
//	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		System.out.println("��������Ʈ ��ȸ ��û");
//		
//		String member_id = request.getParameter("login_id");
//		
//		
//		System.out.println(member_id+"�� ��������Ʈ ��ȸ");
//		
//		MemberDAO dao = new SelectPointDAO();
//		
//		MemberVO vo = dao.login(member_id, member_pw);
//		
//		response.setContentType("text/plain; charset=utf-8");
//		PrintWriter out = response.getWriter();
//		
//		if(vo != null) {
//			out.print(vo.getMember_id());
//			out.print(vo.getMember_pw());
//			out.print(vo.getMember_phone());
//			out.print(vo.getMember_region());
//			out.print(vo.getMember_point());
//			
//			System.out.println(vo.getMember_id()+"/"+vo.getMember_pw()+"/"+vo.getMember_phone()+"/"+vo.getMember_region()+"/"+vo.getMember_point());
//		}else {
//			out.print("");
//		}
//		
//		
//	}
//
//}
